export interface IYetiProduct {
    SKU: string,
    Product_Name: string,
    Price: string,
    //Description: string,
    Product_Category: number,
    ImageName: string,
}