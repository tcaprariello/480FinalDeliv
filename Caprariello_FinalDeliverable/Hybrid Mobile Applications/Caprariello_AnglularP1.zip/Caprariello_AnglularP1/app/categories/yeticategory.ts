export interface IYetiCategory {
    CatID: number;
    CatName: string;
}