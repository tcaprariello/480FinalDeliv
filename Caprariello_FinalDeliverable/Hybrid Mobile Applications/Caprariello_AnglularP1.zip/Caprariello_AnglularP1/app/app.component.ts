import { Component } from '@angular/core';

@Component({
    selector: 'pm-app',
     templateUrl: 'app/app.component.html'
})
export class AppComponent {
    pageTitle: string = `Caprariello - Project 1`;
}
